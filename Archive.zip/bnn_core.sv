import fsm_pkg::*;

module bnn_core #(
    parameter TOTAL_WORDS = 8 // 8 words * 32 bits = 256 total inputs/weights
)(
    input  logic        clk,
    input  logic        rstn,         
    input  logic        start,
    input  logic [31:0] in_ptr,
    input  logic [31:0] wt_ptr,

    // Inputs BRAM Interface
    output logic [31:0] inp_bram_addr,
    input  logic [31:0] inp_bram_dout,

    // Weights BRAM Interface
    output logic [31:0] wt_bram_addr,
    input  logic [31:0] wt_bram_dout,

    // Control & Output Signals
    output logic        busy,
    output logic        done,
    output logic [31:0] result
);

    // dynamic bit-width calculations based on TOTAL_WORDS
    localparam ACCUM_WIDTH = $clog2(TOTAL_WORDS * 32) + 1;
    localparam WORD_WIDTH  = $clog2(TOTAL_WORDS);

    // internal State Registers
    state_t state;
   
    logic [WORD_WIDTH-1:0]    word_idx;     // Tracks 0..(TOTAL_WORDS-1)
    logic [31:0]              offset_count; // Byte address offset (+4 bytes per word)
    logic [ACCUM_WIDTH-1:0]   accumulator;  // Sized to prevent overflow

    logic [31:0] inputs_reg;
    logic [31:0] weights_reg;

    

    logic bnn_done_reg;

    logic [31:0] xnor_result;

    logic [1:0] stage1 [0:15];
    logic [2:0] stage2 [0:7];
    logic [3:0] stage3 [0:3];
    logic [4:0] stage4 [0:1];
    integer i;

    logic [5:0] sum_reg;
    // --- Sequential Logic Block ---
    always_ff @(posedge clk) begin

    $display("state=%0d busy=%b done=%b  word=%0d",
         state, busy, done, word_idx);

        if (rstn == 1'b0) begin
            state         <= IDLE;
            busy          <= 1'b0;
            done          <= 1'b0;
            result        <= 32'b0;
            inp_bram_addr <= 32'b0;
            wt_bram_addr  <= 32'b0;
            offset_count  <= 32'b0;
            word_idx      <= 3'b0;
            

            
            accumulator   <= '0;
            inputs_reg    <= 32'b0;
            weights_reg   <= 32'b0;
        end else begin
            case (state)

                IDLE: begin
                

                    if (start) begin
                        
                        word_idx      <= '0;
                        accumulator   <= '0;
                        offset_count  <= 32'd0;
                        busy          <= 1'b1;
                        state         <= FETCH;
                        done          <=1'b0;

                        // drive initial BRAM address read request
                        inp_bram_addr <= in_ptr;
                        wt_bram_addr  <= wt_ptr;
                    end
                end

                FETCH: begin
                    // latch data returned from BRAM (1-cycle read latency)
                    inputs_reg  <= inp_bram_dout;
                    weights_reg <= wt_bram_dout;
                    
                    state       <= BUSY;
                end

                BUSY: begin
                    
                   
                   accumulator <= accumulator + {{(ACCUM_WIDTH-6){1'b0}}, sum_reg};

                    
                   

                    // 3. word completion check (reached bit index 31)
                    
                        if ((32'(word_idx)) < (TOTAL_WORDS - 1)) begin
                            
                            offset_count  <= offset_count + 32'd4;
                            
                            // issue read request for the next 32-bit word
                            inp_bram_addr <= in_ptr + offset_count + 32'd4;
                            wt_bram_addr  <= wt_ptr + offset_count + 32'd4;
                            // All words processed
                            
                        end 
                     

                    
                        if ((32'(word_idx)) == (TOTAL_WORDS - 1)) begin
                            state <= READY;
                        end else begin
                            word_idx <= word_idx + 1'b1;
                            state    <= FETCH; // Next cycle will correctly sample valid BRAM data!
                        end
                      
                end 
    
                READY: begin
                    busy   <= 1'b0;
                    done   <= 1'b1;
                    result <= 32'(accumulator);
                    state  <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end


    always_comb begin 

       
        
            
                xnor_result = ~(inputs_reg ^ weights_reg);

                for(i=0;i<16;i++) begin 
                stage1[i] = xnor_result[2*i] + xnor_result[2*i+1];
                end  

                for(i=0;i<8;i++) begin 
                stage2[i] = stage1[2*i] + stage1[2*i+1];
                end 

                for(i=0;i<4;i++) begin 
                    stage3[i] = stage2[2*i] + stage2[2*i+1];
                end 

                for(i=0;i<2;i++) begin 
                    stage4[i] = stage3[2*i] + stage3[(2*i)+1];
                end 

                sum_reg = stage4[0] + stage4[1];
    end 
    


endmodule