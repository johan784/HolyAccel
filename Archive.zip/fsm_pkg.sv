package fsm_pkg;

typedef enum logic [1:0] {
    IDLE = 2'b00,
    FETCH= 2'b01,
    BUSY = 2'b10,
    READY = 2'b11
} state_t;

endpackage 



